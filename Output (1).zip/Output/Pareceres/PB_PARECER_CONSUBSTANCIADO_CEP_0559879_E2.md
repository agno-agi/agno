## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa: A5288 -Tratamento com tecnologia de ponta em locais com poucos recursos para otimizar a terapia combinada após a falha viral

Instituiçªo Proponente:

Versªo:

CAAE:

Sandra Wagner Cardoso

Instituto de Pesquisa Clínica Evandro Chagas - IPEC / FIOCRUZ

4

00893812.9.0000.5262

`rea TemÆtica:

Nœmero do Parecer:

559.879

## DADOS DO PARECER

Pesquisas com coordenaçªo e/ou patrocínio originados fora do Brasil, excetuadas aquelas com copatrocínio do Governo Brasileiro;

Division of AIDS US National Institute of Allergy and Infectious Diseases Patrocinador Principal:

Nœmero do Parecer:

Data da Relatoria:

559.879

17/03/2014

## Apresentaçªo do Projeto:

Carta Emenda de 19/02/2014 ao protocolo de pesquisa A5288, incluindo o centro participante, Hospital Nossa Senhora da Conceiçªo (Endereço: Av. Francisco Trein, 596 ¿ Bloco A, 4' andar Porto Alegre, RS), tendo como pesquisador Dr. Breno Riegel Santos e estimado o recrutamento de 40 pacientes pelo referido centro.

## Objetivo da Pesquisa:

Conforme parecer consubstanciado do CEP (402.937)

## Avaliaçªo dos Riscos e Benefícios:

Adequada

ComentÆrios e Consideraçıes sobre a Pesquisa:

Nªo se aplica

Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nªo se aplica

## Recomendaçıes:

Anexar declaraçªo de aprovaçªo do CEP do referido centro.

21.045-900

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

Continuaçªo do Parecer: 559.879

Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo se aplica

Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Sim

Consideraçıes Finais a critØrio do CEP:

O colegiado acatou parecer do relator. Aguarda-se parecer final da CONEP, para sua aprovaçªo.

O presente projeto, seguiu nesta data para anÆlise da CONEP e só tem o seu início autorizado após a aprovaçªo pela mesma.

RIO DE JANEIRO, 31 de Março de 2014

LØa Ferreira Camillo-Coura

(Coordenador) Assinador por:

21.045-900

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->