## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Título da Pesquisa: Investigaçªo sobre um programa de prevençªo combinando aspectos biomØdicos e sociocomportamentais para mulheres transexuais e travestis no Rio de Janeiro, Brasil

Pesquisador:

Beatriz Grinsztejn

`rea TemÆtica:

Pesquisas com coordenaçªo e/ou patrocínio originados fora do Brasil, excetuadas aquelas com copatrocínio do Governo Brasileiro;

Versªo:

1

Instituiçªo Proponente:

CAAE:

Instituto de Pesquisa Clínica Evandro Chagas - IPEC / FIOCRUZ

31754314.9.0000.5262

Division of AIDS US National Institute of Allergy and Infectious Diseases Patrocinador Principal:

## DADOS DO PARECER

Nœmero do Parecer:

Data da Relatoria:

733.278

14/07/2014

## Apresentaçªo do Projeto:

Projeto bem apresentado, intelegível.

## Objetivo da Pesquisa:

Claros.

## Avaliaçªo dos Riscos e Benefícios:

Bem explicada.

## ComentÆrios e Consideraçıes sobre a Pesquisa:

Pesquisa com mulheres transexuais e travestis, pessoas que demandam atençªo especial em relaçªo à prevençªo da infecçªo pelo HIV.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Rever o TCLE, conforme o item abaixo "Conclusıes ou PendŒncias e Lista de Inadequaçıes".

## Recomendaçıes:

Nªo hÆ recomendaçıes.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Em relaçªo ao TCLE:

21.045-900

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

Continuaçªo do Parecer: 733.278

- 1.Incluir um nœmero de celular;
- 2.Correçıes:
- a) DeverÆ observar o gŒnero feminino em todo o texto;
- b) PÆg. 2 - 3' parÆgrafo: Excluir a frase - 'Este nœmero vai depender do mØtodo de saturaçªo teórica, que preconiza a interrupçªo das entrevistas quando houver saturaçªo das informaçıes sobre o tema estudado'; c) PÆg. 3 - 1' parÆgrafo: Excluir o final da frase - 'ou em uma sala com privacidade em uma ONG', pois nªo Ø mencionada a palavra ONG no projeto;
- d) PÆg. 3 - No item: Que efeitos secundÆrios ou riscos posso esperar por participar do estudo? Nas frases:
- 'Entretanto, nós nªo podemos garantir que dos outros participantes do grupo mantenham tudo confidencial'. 'Nós pediremos a todos no grupo para manter confidencial tudo que for falado'. 'Inclusive Ø melhor usar somente o prenome ou um nome fictício de sua escolha durante a discussªo', substituir por: 'Entretanto, nós nªo podemos garantir dos outros participantes do grupo a confidencialidade'. 'Nós pediremos a todos no grupo para manter sigilo de tudo que for falado'. 'Inclusive Ø melhor usar somente um nome fictício de sua escolha durante a discussªo';
- e) PÆg. 4 - 3' parÆgrafo: 'Solicitaremos as participantes a usarem somente nomes fictícios ou seus primeiros nomes e a nªo revelarem a ninguØm fora do grupo o que foi falado durante a sessªo de grupo focal'. 'No entanto, nªo podemos garantir que todos os participantes do grupo mantenham as discussıes dos grupos privadas'. 'Suas informaçıes confidenciais podem ser reveladas por força da lei', substituir por: "Solicitaremos às participantes a usarem somente nomes fictícios e a nªo revelarem a ninguØm fora do grupo o que foi falado durante a sessªo de grupo focal'. 'No entanto, nªo podemos garantir que todos os participantes do grupo mantenham sigilo'. 'Suas informaçıes confidenciais só podem ser reveladas por força da lei'.

Pendente

## Situaçªo do Parecer:

Necessita Apreciaçªo da CONEP:

Sim

21.045-900

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF:

Município:

RJ

RIO DE JANEIRO

<!-- image -->

Continuaçªo do Parecer: 733.278

## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

RIO DE JANEIRO, 30 de Julho de 2014

LØa Ferreira Camillo-Coura (Coordenador) Assinado por:

21.045-900

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF:

Município:

RJ

RIO DE JANEIRO

<!-- image -->