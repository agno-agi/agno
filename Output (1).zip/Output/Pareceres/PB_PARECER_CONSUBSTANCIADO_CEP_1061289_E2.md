## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa:

Instituiçªo Proponente:

Versªo:

CAAE:

Um estudo de fase IIa para avaliar a segurança, tolerabilidade e farmacocinØtica do inibidor de integrase do HIV injetÆvel experimental, GSK1265744, em homens e mulheres nªo infectados pelo HIV

Beatriz Grinsztejn

Instituto de Pesquisa Clínica Evandro Chagas - IPEC / FIOCRUZ

5

31198514.8.0000.5262

`rea TemÆtica:

Division of AIDS US National Institute of Allergy and Infectious Diseases Patrocinador Principal:

## DADOS DO PARECER

Nœmero do Parecer:

Data da Relatoria:

1.061.289

11/05/2015

## Apresentaçªo do Projeto:

Trata-se de uma emenda ao projeto HPTN 077, aprovado neste CEP em 11/08/2014 (CAAE: 31198514.8.0000.5262). O HPTN 077 Ø um estudo em fase II sobre um novo fÆrmaco para terapia antirretroviral a ser administrado em indivíduos saudÆveis e com a utilizaçªo de placebo. Nesta emenda a pesquisadora principal apresenta um novo centro coparticipante.

## Objetivo da Pesquisa:

Trata-se de inclusªo de um centro coparticipante do estudo, a FUNDACAO PRO-INSTITUTO DE HEMATOLOGIA do Estado do Rio de Janeiro (FUNDARJ).

## Avaliaçªo dos Riscos e Benefícios:

Permanecem os mesmos descritos no Parecer 938.938, de 27/01/2015.

## ComentÆrios e Consideraçıes sobre a Pesquisa:

Proposta de inclusªo de um centro coparticipante do estudo.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

A proposta inclui um Termo de Compromisso da pesquisadora principal com a anuŒncia do Diretor da nova instituiçªo coparticipante, em conformidade com as exigŒncias da Resoluçªo 466/2012.

21.040-360

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

Continuaçªo do Parecer: 1.061.289

## Recomendaçıes:

Pela aprovaçªo.

Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ.

Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 15 de Maio de 2015

Mauro Brandªo Carneiro (Coordenador) Assinado por:

21.040-360

(21)3865-9585

E-mail:

cep@ipec.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO DE PESQUISA CL˝NICA EVANDRO CHAGAS IPEC / FIOCRUZ

<!-- image -->