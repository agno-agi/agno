## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa: A5372 - Interaçıes medicamentosas entre rifapentina e dolutegravir em pessoas coinfectadas com HIV/ILTB

Instituiçªo Proponente:

Versªo:

CAAE:

Beatriz Grinsztejn

INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ

2

27858720.0.1001.5262

`rea TemÆtica:

Patrocinador Principal:

## DADOS DA NOTIFICA˙ˆO

Outros

carta

aprovaçªo (re-aprovaçªo) se deve a uma exigŒncia do FDA e ICH GCP guidelines, Justificativa:

06/01/2021

Parecer Consubstanciado Emitido

Tipo de Notificaçªo:

Situaçªo da Notificaçªo:

Data do Envio:

Detalhe:

## DADOS DO PARECER

Nœmero do Parecer:

4.501.834

## Apresentaçªo da Notificaçªo:

Trata-se de solicitaçªo de reaprovaçªo do projeto em epígrafe, aprovado por este CEP conforme Parecer Consubstanciado n' 3.819.722, de 03/02/2020.

## Objetivo da Notificaçªo:

De acordo com a Carta enviada ao CEP pela pesquisadora responsÆvel, a notificaçªo visa atender solicitaçªo do Patrocinador do estudo (DAIDS/NIAID/NIH) com o objetivo de obter 'a reaprovaçªo anual do referido protocolo e seus anexos (...). Tal reaprovaçªo se deve a uma exigŒncia do FDA e ICH GCP guidelines, cujos padrıes desses órgªos sªo seguidos pelo patrocinador do estudo'.

## Avaliaçªo dos Riscos e Benefícios:

Nªo se aplica.

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 4.501.834

## ComentÆrios e Consideraçıes sobre a Notificaçªo:

Conforme relato da pesquisadora responsÆvel, 'A aprovaçªo inicial do estudo se deu em 03/02/20 por meio do parecer 3.819.722, e foi registrado na DAIDS em 30/03/20. O centro ainda aguarda autorizaçªo do patrocinador para iniciar o estudo'.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nesta solicitaçªo de reaprovaçªo foram considerados os seguintes documentos:

- - Protocolo Versªo FINAL 1.0 de 12 de novembro de 2019;
- - Carta emenda versªo 1.0 de 21 de janeiro de 2020;
- - TCLE versªo final 1.0 de 12 de novembro de 2019. Adaptado para o INI em 10 de janeiro de 2020. Modificado pela carta emenda 1 de 14 de fevereiro de 2020.

Os seguintes Registros devem ser considerados:

- - O nœmero do FWA do INI/Fiocruz: 00002548;
- - O nœmero do IRB do CEP-INI: 00004170.

## Recomendaçıes:

Nªo hÆ.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ óbice Øtico à reaprovaçªo anual do projeto.

## Consideraçıes Finais a critØrio do CEP:

A reaprovaçªo anual deste projeto foi analisada na reuniªo do Colegiado de 18 de janeiro de 2021, e aprovada para o período de 03 de fevereiro de 2021 a 02 de fevereiro de 2022.

## Este parecer foi elaborado baseado nos documentos abaixo relacionados:

| Tipo Documento   | Arquivo                           | Postagem            | Autor        | Situaçªo   |
|------------------|-----------------------------------|---------------------|--------------|------------|
| Outros           | Reaprovacao_anual_2021_A5372.pdf  | 06/01/2021 09:20:12 | Tânia Krstic | Postado    |
| Outros           | Reaprovacao_anual_2021_A5372.docx | 06/01/2021 09:20:19 | Tânia Krstic | Postado    |

## Situaçªo do Parecer:

Aprovado

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 4.501.834

## Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 18 de Janeiro de 2021

Mauro Brandªo Carneiro (Coordenador(a)) Assinado por:

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->