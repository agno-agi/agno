## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa: A5379 - Potencializaçªo de vacinaçªo contra vírus da hepatite B (HBV) em pessoas vivendo com HIV (BEe-HIVe): Avaliaçªo da vacina HEPLISAV-B

Instituiçªo Proponente: INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ Division of AIDS US National Institute of Allergy and Infectious Diseases Patrocinador Principal:

Versªo:

CAAE:

Hugo Perazzo Pedroso Barbosa

3

28483920.9.1001.5262

`rea TemÆtica:

## DADOS DA NOTIFICA˙ˆO

Outros

Reaprovaçªo anual

Apresentar a reaprovaçªo anual do estudo para atender as exigŒncias do Justificativa:

11/02/2021

Parecer Consubstanciado Emitido

Tipo de Notificaçªo:

Situaçªo da Notificaçªo:

Data do Envio:

Detalhe:

## DADOS DO PARECER

Nœmero do Parecer:

4.567.374

## Apresentaçªo da Notificaçªo:

Trata-se de solicitaçªo de reaprovaçªo do projeto em epígrafe, aprovado por este CEP conforme Parecer Consubstanciado n. 3.908.618, de 10 de Março de 2020.

## Objetivo da Notificaçªo:

De acordo com a Carta enviada ao CEP pelo pesquisador responsÆvel, a notificaçªo visa atender solicitaçªo do Patrocinador do estudo (National Institute of Allergy and Infectious Diseases) com o objetivo de obter "a reaprovaçªo anual do referido protocolo e seus anexos (...). Tal reaprovaçªo se deve a uma exigŒncia do FDA e ICH GCP guidelines, cujos padrıes desses órgªos sªo seguidos pelo patrocinador do estudo".

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 4.567.374

## Avaliaçªo dos Riscos e Benefícios:

Nªo se aplica.

## ComentÆrios e Consideraçıes sobre a Notificaçªo:

Conforme relato do pesquisador responsÆvel, "Após aprovaçªo inicial do estudo, o mesmo ainda nªo foi iniciado pois aguarda a decisªo do patrocinador de retomar as pesquisas clínicas após a pandemia de Coronavírus".

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nesta solicitaçªo de reaprovaçªo foram considerados os seguintes documentos:

- - Protocolo Versªo FINAL 1.0 de 11 de outubro de 2019;
- - Carta emenda versªo 1.0 de 28 de janeiro de 2020;
- -  TCLE versªo final 1.0 de 11 de outubro de 2019. Adaptado para o INI em 21 de janeiro de 2020. Modificado pela carta emenda 1 de 01 de abril de 2020.

Os seguintes Registros devem ser considerados:

- - O nœmero do FWA do INI/Fiocruz: 00002548;
- - O nœmero do IRB do CEP-INI: 00004170.

## Recomendaçıes:

Nªo hÆ.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ óbice Øtico à reaprovaçªo anual do projeto.

## Consideraçıes Finais a critØrio do CEP:

A reaprovaçªo anual do projeto foi aprovada em reuniªo do Colegiado, realizada em 01 de março de 2021, para o período de 11 de março de 2021 a 10 de março de 2022.

## Este parecer foi elaborado baseado nos documentos abaixo relacionados:

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 4.567.374

| Tipo Documento   | Arquivo                          | Postagem            | Autor                       | Situaçªo   |
|------------------|----------------------------------|---------------------|-----------------------------|------------|
| Outros           | A5379_reaprovacao_anual_2021.pdf | 11/02/2021 12:33:23 | THIAGO PAIVA NUNES DA SILVA | Postado    |

Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 01 de Março de 2021

Mauro Brandªo Carneiro (Coordenador(a)) Assinado por:

21.040-360

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO