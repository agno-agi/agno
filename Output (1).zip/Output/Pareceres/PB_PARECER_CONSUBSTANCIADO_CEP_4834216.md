## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa: A5379 - Potencializaçªo de vacinaçªo contra vírus da hepatite B (HBV) em pessoas vivendo com HIV (BEe-HIVe): Avaliaçªo da vacina HEPLISAV-B

Instituiçªo Proponente: INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ Division of AIDS US National Institute of Allergy and Infectious Diseases Patrocinador Principal:

Versªo:

CAAE:

Hugo Perazzo Pedroso Barbosa

6

28483920.9.1001.5262

`rea TemÆtica:

## DADOS DA NOTIFICA˙ˆO

Outros

TCLE

Trata-se de uma modificaçªo administrativa no rodapØ do TCLE para grÆvidas, com

10/06/2021

Parecer Consubstanciado Emitido

Tipo de Notificaçªo:

Situaçªo da Notificaçªo:

Data do Envio:

Justificativa:

Detalhe:

## DADOS DO PARECER

Nœmero do Parecer:

4.834.216

## Apresentaçªo da Notificaçªo:

Notificaçªo referente ao protocolo "A5379 - Potencializaçªo de vacinaçªo contra vírus da hepatite B (HBV) em pessoas vivendo com HIV (BEe-HIVe): Avaliaçªo da vacina HEPLISAV-B",

Pesquisador ResponsÆvel: Hugo Perazzo Pedroso Barbosa.

## Objetivo da Notificaçªo:

A Notificaçªo objetiva apenas corrigir a versªo do protocolo vigente no rodapØ do documento descrito abaixo:

TCLE GrÆvidas - Versªo FINAL 2.0 de 01 de julho de 2020, adaptado para o INI em 28 de agosto de 2020, modificado em 05 de março de 2021, modificado para atender o CEP em 12 de abril de 2021 e modificado para atender a DAIDS em 09 de junho de 2021.

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 4.834.216

## Avaliaçªo dos Riscos e Benefícios:

Nªo houve alteraçıes nos Riscos e Benefícios.

## ComentÆrios e Consideraçıes sobre a Notificaçªo:

Notificaçªo de ordem administrativa, sem consideraçıes Øticas a serem levantadas.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nªo houve alteraçıes nos Termos de apresentaçªo obrigatória.

## Recomendaçıes:

Nªo hÆ Recomendaçıes a serem feitas.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ óbice Øtico à aprovaçªo desta Notificaçªo (N2).

## Este parecer foi elaborado baseado nos documentos abaixo relacionados:

| Tipo Documento   | Arquivo                                             | Postagem            | Autor                       | Situaçªo   |
|------------------|-----------------------------------------------------|---------------------|-----------------------------|------------|
| Outros           | A5379_TCLE_gravida_track_changes.d ocx              | 10/06/2021 15:27:15 | THIAGO PAIVA NUNES DA SILVA | Postado    |
| Outros           | A5379_TCLE_limpo.docx                               | 10/06/2021 15:27:22 | THIAGO PAIVA NUNES DA SILVA | Postado    |
| Outros           | carta_de_encaminhamento_correcao_T cle_gravidas.pdf | 10/06/2021 15:27:27 | THIAGO PAIVA NUNES DA SILVA | Postado    |

## Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Nªo

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->

Continuaçªo do Parecer: 4.834.216

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

RIO DE JANEIRO, 07 de Julho de 2021

Mauro Brandªo Carneiro (Coordenador(a)) Assinado por:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365

Manguinhos

UF:

Município:

RJ

RIO DE JANEIRO

<!-- image -->