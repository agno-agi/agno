## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa:

Instituiçªo Proponente:

Versªo:

CAAE:

A5371 - Estudo piloto aberto de braço œnico de semaglutide para doença hepÆtica gordurosa nªo alcoólica (DHGNA), síndrome metabólica com resistŒncia insulínica, aumento de lipídios hepÆticos e risco aumentado de doenças cardiovasculares (estudo SLIM LIVER)

Hugo Perazzo Pedroso Barbosa

INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ

2

39697820.9.0000.5262

`rea TemÆtica:

Division of AIDS US National Institute of Allergy and Infectious Diseases

Patrocinador Principal:

## DADOS DA NOTIFICA˙ˆO

Outros

Reaprovaçªo anual

Encaminhar a reaprovaçªo anual do estudo, para atender às exigŒncias do

15/12/2021

Parecer Consubstanciado Emitido

Tipo de Notificaçªo:

Situaçªo da Notificaçªo:

Data do Envio:

Justificativa:

Detalhe:

## DADOS DO PARECER

Nœmero do Parecer:

5.202.795

## Apresentaçªo da Notificaçªo:

Trata-se de solicitaçªo de reaprovaçªo do projeto em epígrafe, aprovado por este CEP conforme Parecer Consubstanciado n' 4.531.994, de 09/02/2021.

## Objetivo da Notificaçªo:

De acordo com a Carta enviada ao CEP pelo pesquisador responsÆvel, a notificaçªo visa atender solicitaçªo do Patrocinador do estudo (National Institute of Allergy and Infectious Diseases) com o objetivo de obter 'a reaprovaçªo anual do referido protocolo e seus anexos (...). Tal reaprovaçªo se deve a uma exigŒncia do FDA e ICH GCP guidelines, cujos padrıes desses órgªos sªo seguidos pelo patrocinador do estudo'.

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 5.202.795

## Avaliaçªo dos Riscos e Benefícios:

Nªo se aplica.

## ComentÆrios e Consideraçıes sobre a Notificaçªo:

Conforme relato do pesquisador responsÆvel, 'A aprovaçªo inicial do estudo se deu em 09/02/2021 por meio do parecer 4.531.994 e foi registrado na DAIDS em 05/05/2021. O centro ainda aguarda autorizaçªo do patrocinador para iniciar o estudo'.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nesta solicitaçªo de reaprovaçªo foram considerados os seguintes documentos:

- - TCLE Principal - Versªo FINAL 2.0 de 22 de junho de 2020, adaptado para o INI em 09 de setembro de 2020 e modificado para atender o CEP em 05 de janeiro de 2021; e
- - Protocolo Versªo Final 2.0 de 22 de junho de 2020.

Os seguintes Registros devem ser considerados:

- - O nœmero do FWA do INI/Fiocruz: 00002548;
- - O nœmero do IRB do CEP-INI: 00004170.

## Recomendaçıes:

Nªo hÆ.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ óbice Øtico à reaprovaçªo anual do projeto.

## Consideraçıes Finais a critØrio do CEP:

A reaprovaçªo anual do projeto foi aprovada em reuniªo do Colegiado realizada em 17 de janeiro de 2022, para o período de 09 de fevereiro de 2022 a 08 de fevereiro de 2023.

## Este parecer foi elaborado baseado nos documentos abaixo relacionados:

| Tipo Documento Arquivo                                                                                                                                                       | Postagem                              | Autor   | Situaçªo   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|---------|------------|
| 21.040-900 (21)3865-9585 E-mail: Endereço: Bairro: CEP: Telefone: Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Manguinhos UF: Município: RJ RIO DE JANEIRO | cep@ini.fiocruz.br Rodrigues da Silva |         |            |

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 5.202.795

| Outros   | A5371_reaprovacao_anual_2022.pdf   | 15/12/2021 13:17:15   | THIAGO PAIVA NUNES DA SILVA   | Postado   |
|----------|------------------------------------|-----------------------|-------------------------------|-----------|
| Outros   | A5371_reaprovacao_anual_2022.docx  | 15/12/2021 13:17:19   | THIAGO PAIVA NUNES DA SILVA   | Postado   |

## Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 17 de Janeiro de 2022

Mauro Brandªo Carneiro (Coordenador(a)) Assinado por:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO