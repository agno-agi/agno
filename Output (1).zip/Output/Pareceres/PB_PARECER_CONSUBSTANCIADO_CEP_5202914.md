## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DO PROJETO DE PESQUISA

Pesquisador:

Título da Pesquisa: A5372 - Interaçıes medicamentosas entre rifapentina e dolutegravir em pessoas coinfectadas com HIV/ILTB

Instituiçªo Proponente:

Versªo:

CAAE:

Beatriz Grinsztejn

INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ

5

27858720.0.1001.5262

`rea TemÆtica:

Patrocinador Principal:

## DADOS DA NOTIFICA˙ˆO

Outros

Reaprovaçªo anual do estudo A5372

Solicitaçªo de reaprovaçªo anual para o A5372

17/12/2021

Parecer Consubstanciado Emitido

Tipo de Notificaçªo:

Situaçªo da Notificaçªo:

Data do Envio:

Justificativa:

Detalhe:

## DADOS DO PARECER

Nœmero do Parecer:

5.202.914

## Apresentaçªo da Notificaçªo:

Trata-se de solicitaçªo de reaprovaçªo do projeto em epígrafe, aprovado por este CEP conforme Parecer Consubstanciado n' 3.819.722, de 03/02/2020.

## Objetivo da Notificaçªo:

De acordo com a Carta enviada ao CEP pela pesquisadora responsÆvel, a notificaçªo visa atender solicitaçªo dos Patrocinadores do estudo (National Institute of Allergy and Infectious Diseases) com o objetivo de obter 'a reaprovaçªo anual do referido protocolo e seus anexos (...). Tal reaprovaçªo se deve a uma exigŒncia do FDA e ICH GCP guidelines, cujos padrıes desses órgªos sªo seguidos pelo patrocinador do estudo'.

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 5.202.914

## Avaliaçªo dos Riscos e Benefícios:

Nªo se aplica.

## ComentÆrios e Consideraçıes sobre a Notificaçªo:

Conforme relato da pesquisadora responsÆvel, 'após aprovaçªo inicial do estudo, o mesmo ainda nªo foi iniciado pois aguarda a decisªo do patrocinador de retomar as pesquisar clínicas após a pandemia de Coronavírus'.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Nesta solicitaçªo de reaprovaçªo foram considerados os seguintes documentos:

- • Protocolo Versªo FINAL 2.0 de 11 de junho de 2021; e
- • TCLE versªo final 2.0 de 11 de junho de 2021.

Os seguintes Registros devem ser considerados:

- - O nœmero do FWA do INI/Fiocruz: 00002548;
- - O nœmero do IRB do CEP-INI: 00004170.

## Recomendaçıes:

Nªo hÆ.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Nªo hÆ óbice Øtico à reaprovaçªo anual do projeto.

## Consideraçıes Finais a critØrio do CEP:

A reaprovaçªo anual do projeto foi aprovada em reuniªo do Colegiado realizada em 17 de janeiro de 2022, para o período de 03 de fevereiro de 2022 a 02 de fevereiro de 2023.

## Este parecer foi elaborado baseado nos documentos abaixo relacionados:

| Tipo Documento   | Arquivo                          | Postagem   | Autor            | Situaçªo   |
|------------------|----------------------------------|------------|------------------|------------|
| Outros           | A5372_reaprovacao_anual_submissa | 17/12/2021 | Raquel Malaguthi | Postado    |

| Endereço:   | Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva   | Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva   |
|-------------|-------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| Bairro:     | Manguinhos                                                                          | 21.040-900 CEP:                                                                     |
| UF: RJ      | Município: RIO DE JANEIRO                                                           |                                                                                     |
| Telefone:   | (21)3865-9585                                                                       | E-mail: cep@ini.fiocruz.br                                                          |

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 5.202.914

| Outros   | o_ao_cep_2022.docx                                          | 15:27:36            | de Souza                  | Postado   |
|----------|-------------------------------------------------------------|---------------------|---------------------------|-----------|
| Outros   | A5372_reaprovacao_anual_submissao_ ao_cep_2022_assinado.pdf | 17/12/2021 15:29:28 | Raquel Malaguthi de Souza | Postado   |

Situaçªo do Parecer:

Aprovado

Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 17 de Janeiro de 2022

Mauro Brandªo Carneiro (Coordenador(a)) Assinado por:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO