## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## PARECER CONSUBSTANCIADO DO CEP

## DADOS DA EMENDA

Pesquisador:

Título da Pesquisa: Estudo de Fase IV para avaliar a imunogenicidade a segurança da vacina contra Febre Amarela em pacientes infectados pelo HIV

Instituiçªo Proponente:

Versªo:

CAAE:

Lara Esteves Coelho

INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI/FIOCRUZ

7

67136517.9.0000.5262

`rea TemÆtica:

Financiamento Próprio

Patrocinador Principal:

## DADOS DO PARECER

Nœmero do Parecer:

6.158.625

## Apresentaçªo do Projeto:

Os tópicos Apresentaçªo do projeto, Objetivo da Pesquisa e Avaliaçªo dos Riscos e Benefícios estªo de acordo com o documento PB\_INFORMA˙ÕES\_B`SICAS\_2144890\_E5, versªo 7, de 19/05/2023:

## Introduçªo:

## CONTEXTO:

A Febre Amarela (FA) Ø uma doença zoonótica causada por um vírus da família Flaviviridae sendo endŒmica e epidŒmica em alguns países da AmØrica Latina e `frica. O ciclo de transmissªo da Febre Amarela Ø composto por primatas, humanos e mosquitos. Primatas nªo humanos e humanos sªo os hospedeiros vertebrados do vírus e algumas espØcies de mosquitos (Aedes, Haemagogus, Sabethes) atuam tanto como vetores e como reservatórios do vírus.

A Febre Amarela urbana (transmitida pelo Aedes aegypti) encontra-se erradicada no Brasil desde 1942, e a Febre Amarela silvestre permaneceu endŒmica em vÆrias regiıes do país nesse período. Desde dezembro de 2016, o Brasil vem experimentando o maior surto de Febre Amarela ocorrido nos œltimos anos. AtØ 20/03/2017 foram notificados 1561 casos suspeitos (850 em investigaçªo, 448 confirmados) e 264 óbitos (144 confirmados, 110 em investigaçªo e 10 descartados). A maior parte dos casos se concentram nos estados de Minas Gerais e Espirito Santo e todos os casos foram definidos como Febre Amarela silvestre. No estado do Rio de Janeiro, foram notificados 5

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 6.158.625

casos (em 2 municípios) (relatório atualizado em 20 março de 2017).

O período de incubaçªo do vírus da Febre Amarela Ø de 3-6 dias. Muitos indivíduos infectados se mantŒm assintomÆticos. A doença sintomÆtica pode se manifestar com sintomas brandos atØ sua forma severa com falŒncia orgânica mœltipla e hemorragia. Cerca de 15% dos indivíduos sintomÆticos podem evolui para a forma grave da doença que inclui insuficiŒncia renal, insuficiŒncia hepÆtica, hemorragia e choque circulatório. Dos pacientes que evoluem para forma grave (insuficiŒncia renal e hepÆtica) 25-50% morrem.

## VACINA CONTRA FEBRE AMARELA:

Nªo existe tratamento específico para a Febre Amarela, e os pacientes sintomÆticos recebem somente cuidados de suporte. A vacina em uso no país Ø produzida por Bio-Manguinhos/Fiocruz e consiste de vírus vivos atenuados da subcepa 17DD, derivada da linhagem original desenvolvida por Theiler e Smith, em 1937. A vacina contra Febre Amarela (17 D ou 17 DD) Ø altamente imunogŒnica (confere imunidade em 95% a 99% dos vacinados), bem tolerada e raramente associada a eventos adversos graves, e Ø utilizada amplamente em indivíduos que vivem em Æreas endŒmicas. A Organizaçªo Mundial de Saœde e o MinistØrio da Saœde Brasileiro recomendam a vacinaçªo de indivíduos com idade entre 9 meses e 60 anos que vivem em Ærea endŒmica ou viajantes com destino a Æreas endŒmicas. Recentemente, em decorrŒncia do surto iniciado em dezembro de 2016 e à ocorrŒncia de transmissªo ativa no estado do Rio de Janeiro, o MinistØrio da Saœde recomendou a vacinaçªo da populaçªo residente e de viajantes o estado do Rio de Janeiro. A vacina contra Febre Amarela Ø contraindicada nos seguintes casos:

- • Crianças menores de 6 meses de idade;
- • Pacientes com imunodepressªo de qualquer natureza;
- • Pacientes com neoplasia;
- · Pacientes infectados pelo HIV com imunossupressªo grave, com a contagem de cØlulas CD4 &lt; 200 cØlulas /mm3 ou menor de 15% do total de linfócitos para crianças menores de 6 anos;
- · Pacientes em tratamento com drogas imunossupressoras (corticosteroides, quimioterapia, radioterapia, imunomoduladores);
- • Pacientes submetidos a transplante de órgªos.

## EVENTOS ADVERSOS RELACIONADOS À VACINA:

Os eventos adversos relacionados à vacina da Febre Amarela sªo pouco frequentes (incidŒncia estimada em 43/100.000 doses), e em sua maioria, sªo caracterizados por eventos leves como

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

cefaleia, febre baixa, mialgia e dor no local da injeçªo. A combinaçªo dos sintomas febre, mialgia e cefaleia foi estimada em 4% dos indivíduos primovacinados e em 2% dos indivíduos revacinados. No entanto, relatos de ocorrŒncia de eventos adversos graves e potencialmente fatais relacionados com a vacina, como doença neurológica vacinal, doença viscerotrópica vacinal, hipersensibilidade e anafilaxia sªo descritos. No Brasil, o risco de eventos adversos fatais relacionados com a vacina de Febre Amarela foi estimado entre 0,043 e 2,13  por  100.000  doses  (intervalo  de  confiança  de  95%:  0,109-12,701  por  100.000).  Anafilaxia, hipersensibilidade e reaçıes alØrgicas sªo eventos raros e podem acontecer em razªo de qualquer um dos componentes da vacina. No Brasil (dados do Sistema de Informaçªo de Eventos Adversos Pós-Vacinaçªo, SI-EAPV), a taxa de incidŒncia por milhªo de doses aplicadas, no período 2001-2003 foi de 1,9 reaçıes (hipersensibilidade de todos os tipos) e 0,2 choque anafilÆtico. Neurotropismo Ø uma característica do vírus da FA selvagem e essa característica tambØm Ø observada, de forma mais branda, no vírus vacinal atenuado. No entanto, a baixa viremia vacinal que segue a vacina Ø insuficiente, na maior parte dos casos, para causar neuroinvasªo. Crianças abaixo dos 6 meses, idosos e indivíduos imunocomprometidos apresentam maior risco de neuroinvasªo pelo vírus vacinal. A doença neurológica pode se apresentar como meningoencefalite, síndrome de Guillain-BarrØ e encefalomielite aguda, podendo ser consequŒncia do efeito direto do vírus vacinal no SNC (a primeira) ou do efeito indireto do vírus (resposta inflamatória). Em geral, a incidŒncia de doença neurológica vacinal relacionada com a vacina de Febre Amarela Ø baixa. Nos Estados Unidos, a incidŒncia em adultos foi estimada em 0,8/100.000 doses de vacina, sendo maior em idosos (idade 60-70 anos: 1,6/100000 e 70 anos: 2,3/100.000). No Brasil, a incidŒncia de doença neurológica vacinal foi estimada em 1,1/100.000 doses de vacina em campanha de vacinaçªo em massa realizada no Rio Grande do Sul em 2008-2009. A doença viscerotrópica vacinal foi descrita somente a partir de 2001, relatos de casos que ocorreram nos Estados Unidos e no Brasil. Sua incidŒncia Ø extremamente baixa, variando entre 0,14/100.000 doses e 0,4/100.000 doses. Clinicamente se assemelha a doença causada pelo vírus selvagem, e os sinais e sintomas descritos incluem como febre, plaquetopenia, aumento de enzimas hepÆticas, icterícia, aumento de creatinofosofoquinase, insuficiŒncia renal, disfunçªo orgânica mœltipla e choque. Os sintomas se iniciam precocemente após a vacina (mØdia de 4 dias, semelhante ao tempo de incubaçªo do vírus selvagem) e os pacientes apresentam elevada carga viral do vírus vacinal. Essa complicaçªo foi observada somente em indivíduos que receberam a vacina pela primeira vez (ausŒncia de imunidade previa contra Febre Amarela).

VACINA DE FEBRE AMARELA EM PACIENTES INFECTADOS PELO HIV:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

As evidŒncias de imunogenicidade e segurança da vacina contra Febre Amarela em pacientes infectados pelo HIV sªo limitadas a poucos estudos, em sua maioria estudos observacionais e relatos de casos. Mais recentemente, em uma revisªo sistemÆtica publicada pela Cochrane Collaboration em 2014 - que inclui 3 estudos observacionais (somando uma populaçªo de estudo de 484 indivíduos infectados pelo HIV) concluiu que a vacina de Febre Amarela Ø segura e imunogŒnica, e que fatores como CD4 elevado e carga viral do HIV baixa estªo associados a títulos mais elevados de anticorpos neutralizantes após a vacina de Febre Amarela. Resultados semelhantes foram descritos por Avelino-Silva et al, em ensaio clínico nªo randomizado conduzido em Sªo Paulo, Brasil. Esse estudo incluiu 12 participantes infectados pelo HIV e 45 nªo infetados pelo HIV. A ocorrŒncia de eventos adversos foi semelhante nos dois grupos. Os títulos de anticorpos neutralizantes contra Febre Amarela foram mais elevados no grupo de participantes HIVnegativos e a relaçªo CD4/CD8 pareceu estar associada à imunogenicidade da vacina em pacientes infetados pelo HIV. A recomendaçªo do MinistØrio da Saœde brasileiro Ø indicar a vacina para todas os indivíduos infectados pelo HIV com CD4 350 cØlulas/mm‡ que vivem em Æreas de risco e oferecer a vacina para aquele com CD4 entre 350 e 200 cØlulas/mm‡. Em relaçªo à ocorrŒncia de eventos adversos graves, existe somente um relato de morte após vacinaçªo em paciente infectado pelo HIV (CD4 108 cØlulas/mm‡) relacionado à ocorrŒncia de doença neurológica vacinal.

## JUSTIFICATIVA:

As seguintes consideraçıes serviram de base para que esse estudo fosse proposto:

- 1. A Febre Amarela Ø uma doença endŒmica em algumas regiıes do Brasil e a vacinaçªo passou a ser recomendada no estado do Rio de Janeiro em março de 2017.
- 2. Na populaçªo geral, a vacina de Febre Amarela Ø altamente imunogŒnica e segura.
- 3. Em indivíduos infectados pelo HIV, a vacina estÆ indicada para aqueles com CD4 &gt; 200 cØlulas/mm‡ que vivem ou viajam para Æreas de risco.
- 4. No entanto, as evidŒncias que norteiam o uso da vacina contra Febre Amarela em indivíduos infectados pelo HIV sªo em sua maioria proveniente de estudos observacionais com pequenos tamanhos amostrais.

## Hipóteses:

- • A imunogenicidade da vacina contra Febre Amarela pode ser afetada pela infecçªo pelo HIV;
- • A vacina contra Febre Amarela Ø segura em indivíduos infectados pelo HIV;

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

- · Os títulos de anticorpos neutralizantes contra Febre Amarela induzidos pela vacina sªo mais elevados em indivíduos HIV positivos com maiores contagens de CD4;
- · Os títulos de anticorpos neutralizantes contra Febre Amarela induzidos pela vacina sªo mais elevados em indivíduos HIV positivos em carga viral suprimida;
- · Os títulos de anticorpos neutralizantes contra Febre Amarela induzidos pela vacina sªo mais elevados em indivíduos HIV positivos com maior razªo CD4/CD8;
- · A viremia pelo vírus da Febre Amarela vacinal podem ser maiores em pacientes infectados pelo HIV do que nos controles HIV negativos;
- · A detecçªo de RNA do vírus da Febre Amarela vacinal na urina pode ser mais sensível e prolongada do que a detecçªo do vírus no sangue (viremia);
- · SoroprevalŒncia para Dengue e Zika podem estar associados a menores viremias pelo vírus da Febre Amarela Vacinal e menor imunogenicidade da vacina (neutralizaçªo cruzada do vírus vacinal pelos anticorpos contra Dengue e Zika);
- ·  A  ativaçªo  imune  elevada,  bem  como  a  exaustªo  do  sistema  imune,  pode  levar  a  uma  menor imunogenicidade da vacina contra a Febre Amarela;
- · A resposta imune inata e adaptativa presente podem impactar diretamente na imunogenicidade induzida pela vacina;
- · A regulaçªo gŒnica de miRNAs influencia na expressªo de citocinas e receptores de cØlulas B indicando novos biomarcadores de imunogenicidade vacinal.

## Metodologia Proposta:

Trata-se de ensaio clínico, fase IV, nªo randomizado, de 1 ano de duraçªo, a ser conduzido dentro da rotina de atendimento aos pacientes portadores de infecçªo pelo HIV acompanhados no Instituto Nacional de Infectologia (INI) pela equipe de pesquisa do Laboratório de Pesquisa Clínica em DST/AIDS deste instituto, onde participantes infectados pelo HIV com CD4 &gt; 200 cØlulas/mm‡ e adultos nªo infectados pelo HIV serªo submetidos a vacinaçªo contra Febre Amarela.

No momento da triagem para vacinaçªo os participantes serªo indagados se estªo interessados em participar deste estudo clínico. O desenho do estudo e o documento do termo de consentimento livre e esclarecido serªo revistos com o participante. Após esclarecimentos de dœvidas, o consentimento deverÆ ser assinado pelo participante (presumindo-se o consentimento) e por um dos membros da equipe do estudo designado pelo pesquisador responsÆvel.

Dos indivíduos elegíveis para o estudo (critØrios explicitados abaixo) serªo obtidos os seguintes dados prØvacinais: história clínica, histórico de vacinaçªo, coleta de sangue para sorologia de

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

Febre Amarela, hemograma, hepatograma, CD4, CD8, carga viral do HIV. Estes dados serªo processados de acordo com as normas do ACTG, para as quais a equipe do laboratório de pesquisa jÆ possui treinamento e para que seja mantido um padrªo internacionalmente aceito. A vacinaçªo ocorrerÆ após a visita clínica e coleta de exames laboratoriais.

Após a vacinaçªo serªo agendadas 5 visitas de seguimento, no 7'-10' dia após a vacina, no 30'-45' dia após vacina e 1, 5 e 10 anos após a vacina, respectivamente. Em todas as visitas de seguimento, os participantes responderªo questionÆrios sobre a ocorrŒncia de eventos adversos e serªo submetidos a coleta de amostras de sangue para anÆlises.

## CritØrios de Inclusªo:

- • Homens e mulheres infectados pelo HIV com idade entre 18 anos de idade e 59 anos;
- · Ter contagem de CD4 &gt; 200 cØlulas/mm‡ no œltimo exame que precede a inclusªo (pelo menos 6 meses antes da inclusªo). Para os voluntÆrios que nªo possuírem resultado de CD4 disponível nos 6 meses anteriores a data de inclusªo, serÆ permitida inclusªo desde que a carga viral do HIV seja indetectÆvel (œltimo exame nos 6 meses que precedem a inclusªo) e o œltimo resultado de CD4 superior a 350 cØlulas/mm‡ (independentemente do intervalo entre o exame e a inclusªo);
- · Homens e mulheres nªo infectados pelo HIV (teste rÆpido anti-HIV negativo na inclusªo) com idade entre 18 anos de idade e 59 anos (grupo de controle), em boa saœde, sem história mØdica significante (como as descritas nos critØrios de exclusªo), e com exame físico de inclusªo sem alteraçıes clínicas significantes;
- • Sem antecedentes de vacinaçªo contra febre amarela;
- · Disponibilidade para comparecer ao INI para os procedimentos da pesquisa no período de 12 meses após a vacinaçªo;
- • Capacidade e vontade do participante de assinar o termo de consentimento livre e esclarecido (TCLE).

## CritØrios de Exclusªo:

- · Indivíduos portadores de outras causas de imunodeficiŒncia como: (diabetes descompensada, insuficiŒncia renal crônica dialítica, insuficiŒncia hepÆtica/cirrose, câncer (exceto carcinomas espinocelular e basocelular de pele e neoplasia in situ relacionada ao HPV) e uso de imunossupressores nos œltimos 6 meses (incluindo uso de prednisona 20mg/dia por 7 ou mais dias ou mais nos œltimos 30 dias);
- • Mulheres gestantes (beta HCG serÆ realizado em todas as mulheres antes da vacina) ou que

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço: Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Bairro:

CEP:

Telefone:

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

Continuaçªo do Parecer: 6.158.625

## estejam amamentando;

- · Alergia à ovo; Alergia a proteínas de aves; Alergia à eritromicina; Alergia à canamicina; Intolerância hereditÆria à frutose;
- · Ter recebido imunoglobulinas ou hemoderivados 3 meses ou qualquer vacina de vírus vivo atenuado 1 mŒs;
- • Histórico de disfunçªo do timo (timoma ou timectomia);
- • Estar em uso de anti-CCR5;
- • Apresentar sintomas de doença aguda grave ou febre 38°C (temperatura axilar);
- · Soropositividade para HIV detectada nos exames prØ-vacinais de indivíduos incluídos no estudo no grupo de nªo infectados pelo HIV;
- · Ter nascido e/ou residido (30 dias ou mais) em estados de transmissªo endŒmica de febre amarela ou que tenham imunizaçªo contra febre amarela como rotina no calendÆrio vacinal (especificamente, Amazonas, ParÆ, Acre, Roraima, Rondônia, Maranhªo, Mato Grosso, Mato Grosso do Sul, Tocantins, GoiÆs, e Minas Gerais após 2001).

## Metodologia de AnÆlise de Dados:

A anÆlise dos dados irÆ considerar os componentes imunogenicidade e reatogenicidade da vacina. A variÆvel resposta de interesse para avaliaçªo da imunogenicidade Ø o título de anticorpos neutralizantes no soro e suas derivaçıes: soropositividade pós-vacinal (30-45 dias e 365 dias após) serÆ definida como títulos de anticorpos igual ou maior do que 2,8 log10 miliunidades internacionais por ml de soro (equivalente à diluiçªo 1:20); soroconversªo serÆ definida como soropositividade após a vacinaçªo em indivíduos soronegativos no teste sorológico prØ-vacinal ou aumento de 4 vezes ou mais nos títulos de anticorpos após a vacinaçªo comparados aos títulos prØ-vacinais.

A anÆlise univariada irÆ representar as características dos grupos de estudo com distribuiçıes de frequŒncias em tabelas (sexo, comorbidade) e histogramas (idade, títulos de anticorpos, razªo dos títulos pós e prØ-vacinais, viremia).

Na anÆlise da reatogenicidade da vacina serªo considerados os eventos adversos pós-vacinais segundo as categorias apresentadas no item 7.1.5 (leve moderado e severo), alteraçıes de parâmetros laboratoriais (em relaçªo aos níveis prØ-vacinais), e a detecçªo e o nível de viremia vacinal (presente/ausente; logaritmo da contagem de partículas virais).

As variÆveis explanatórias principais sªo (1) situaçªo sorológica para HIV e (2) e contagem de CD4+ anterior e próxima à data da vacinaçªo, categorizada em 200-350, 351-500 e &gt;500

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

cØlulas/mm‡. As covariÆveis consideradas para a comparaçªo dos soropositivos e dos soronegativos sªo sexo, idade, carga viral (HIV), tratamento com antirretrovirais (duraçªo), nadir de CD4, razªo CD4/CD8 e comorbidade.

As proporçıes de soroposividade (30-45 dias e 365 dias) e de soconversªo serªo comparadas nos grupos sem e com infecçªo pelo HIV, total e subgrupos de nível de CD4+. A mØdia geomØtrica dos títulos de anticorpos pós-vacinais (30-45 dias e 365 dias) no grupo com infecçªo pelo HIV serÆ comparada com o grupo soronegativo para HIV.

As proporçıes de eventos adversos e de indivíduos com vírus vacinal detectado e as mØdias geomØtricas do nœmero de partículas de vírus vacinal serªo comparadas entre os grupos sem e com infecçªo pelo HIV, total e subgrupos de nível de CD4+.

- O teste do qui-quadrado de Pearson e de tendŒncia linear serªo aplicados para avaliar significância estatística das diferenças de proporçıes, com nível de significância de 5%. A significância estatística das diferenças entre as mØdias serÆ avaliada em anÆlise de variância e teste t.

A associaçªo entre infecçªo pelo HIV e os desfechos soropositividade e soroconversªo para febre amarela, viremia (vírus vacinal), eventos adversos (clínicos) e alteraçıes dos parâmetros laboratoriais serÆ medida pela razªo de proporçıes, bruta e ajustada em modelo de regressªo de Poisson para as covariÆveis sexo, idade e comorbidade. A diferença das mØdias dos logaritmos dos títulos pós-vacinais de anticorpos contra febre amarela serÆ ajustada para as covariÆveis sexo, idade e comorbidade em modelo de regressªo mœltipla. As anÆlises multivariadas tambØm serªo realizadas apenas com os dados do grupo de infectados pelo HIV, incluindo as covariÆveis sexo, idade, tratamento com antirretrovirais (duraçªo), nadir de CD4, razªo CD4/CD8 e comorbidade. A anÆlise multivariada serÆ realizada tambØm com os resultados dos testes sorológicos aos 30-45 dias e 365 dias.

As anÆlises estatísticas serªo realizadas utilizando o programa R versªo 3.3.3.

## Desfecho PrimÆrio:

- (1) a proporçªo de indivíduos inicialmente soronegativos que passam a soropositivos para febre amarela.

## Desfecho SecundÆrio:

- (2) a proporçªo que obtØm aumento de 4 vezes ou mais nos títulos de anticorpos após a vacina contra Febre Amarela, e (3) a mØdia geomØtrica dos títulos de anticorpos nos grupos de

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

Continuaçªo do Parecer: 6.158.625

comparaçªo.

Tamanho da Amostra no Brasil: 400.

Tamanho da Amostra neste Centro: 400.

Grupos em que serªo divididos os participantes da pesquisa neste centro:

Grupo Nªo infectado pelo HIV = 100;

Grupo Infectado pelo HIV CD4 &gt; 350 e &lt; 500 cØlulas/mm‡ = 100;

Grupo Infectado pelo HIV CD4 &lt; 350 cØlulas/mm‡ = 100; e

Grupo Infectado pelo HIV CD4 &gt; 500 cØlulas/mm‡ = 100.

Intervençªo a ser realizada (em todos os grupos): Vacina contra Febre Amarela.

O Estudo Ø MulticŒntrico no Brasil? Nªo.

HaverÆ retençªo de amostras para armazenamento em banco? Sim.

Justificativa:

Para a realizaçªo das anÆlises de cØlulas B, serªo enviadas alíquotas de amostras de PBMC jÆ previstas pelo protocolo para o Mount Sinai - Nova Iorque - EUA. Em sua maioria, essas amostras de PBMC jÆ foram coletadas, processadas e armazenadas; para alguns participantes que ainda nªo realizaram as visitas de Ano 5 do protocolo (que estªo acontecendo atualmente) essas amostras ainda serªo coletadas. É importante ressaltar que nªo serªo necessÆrias coletas adicionais de amostras para a realizaçªo das anÆlises de cØlulas B. Os custos relacionados transporte e anÆlises serªo de responsabilidade do Mount Sinai, e, portanto, nªo haverÆ mudança no orçamento do estudo.

## Objetivo da Pesquisa:

Objetivo PrimÆrio:

Comparar a proporçªo de soroconversªo pela vacina contra febre amarela e a mØdia geomØtrica dos títulos de anticorpos 30-60 dias e 365 dias após a vacinaçªo em indivíduos infectados e em nªo infectados pelo HIV.

## Objetivos SecundÆrios:

- · Avaliar se os títulos de anticorpos neutralizantes contra Febre Amarela estªo associados com marcadores imuno-virológicos do HIV na inclusªo (linfócitos T CD4 +, linfócitos TCD8+ e carga

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

## viral do HIV);

- • Avaliar se os títulos de anticorpos neutralizantes contra Febre Amarela estªo associados ao nadir de CD4;
- · Avaliar se os títulos de anticorpos neutralizantes contra Febre Amarela estªo associados ao uso e ao tempo de uso de terapia antirretroviral;
- · Avaliar o efeito da vacina 17DD na contagem de linfócitos T CD4 +, linfócitos TCD8+ e carga viral do HIV no dia 5 após a vacina;
- • Avaliar a viremia pelo vírus vacinal entre o 3' e 10' dia após a vacina;
- · Avaliar se a viremia pelo vírus vacinal estÆ associada com marcadores imuno-virológicos do HIV na inclusªo (linfócitos T CD4 +, linfócitos TCD8+ e carga viral do HIV);
- · Comparar a incidŒncia de eventos adversos grau 2 ou mais (clínicos e/ou laboratoriais) relacionados com vacina 17DD nos dias 5, 10, 30 após a vacina em indivíduos infectados e em nªo infectados pelo HIV;
- ·  Avaliar a incidŒncia de eventos adversos graves, incluindo doença viscerotrópica vacinal, doença neurológica vacinal, hipersensibilidade e anafilaxia em indivíduos infectados e em nªo infectados pelo HIV;
- · Avaliar fatores (demogrÆficos e clínicos) associados à incidŒncia de eventos adversos vacinais (Grau 2 ou mais);
- ·  Determinar  o  tempo  de  duraçªo  de  proteçªo  contra  febre  amarela  em  portadores  do  vírus  da imunodeficiŒncia  humana  adquirida;
- · Determinar o tempo de a duraçªo dos anticorpos neutralizantes conferidos pela vacinaçªo indivíduos infectados e em nªo infectados pelo HIV;
- ·  Avaliar se marcadores de exaustªo e ativaçªo imune celular e estªo associados com os títulos de anticorpos neutralizantes contra a Febre Amarela;
- · Avaliar o perfil de marcadores plasmÆticos de inflamaçªo e ativaçªo imune em resposta a vacinaçªo estªo associados com os títulos de anticorpos neutralizantes contra a febre Amarela e/ou surgimento de efeitos adversos;
- · Avaliar o perfil das cØlulas centrais da imunidade inata e adaptativa (incluindo cØlulas B), bem como possíveis biomarcadores, relacionados à imunogenicidade da vacina contra a Febre Amarela, frente à infecçªo pelo HIV;
- · Avaliar o desenvolvimento de memória imunológica inata e seu impacto na produçªo de anticorpos neutralizantes contra a Febre Amarela.
- • Avaliar os títulos de anticorpos neutralizantes contra Febre Amarela após dose de reforço da

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

PÆgina 10 de 17

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

vacina contra Febre Amarela (17DD, BioManguinhos) nos participantes incluídos na Etapa 2;

- · Avaliar se a resposta de cØlulas T de memória específicas para a febre amarela estÆ associada com os títulos  de  anticorpos  neutralizantes  após  dose de reforço da vacina contra Febre Amarela (17DD, BioManguinhos) nos participantes incluídos na Etapa 2;
- · Avaliar se a frequŒncia de cØlulas Tfh específica para da febre amarela estÆ associada com os títulos de anticorpos neutralizantes contra a Febre Amarela após dose de reforço da vacina contra Febre Amarela (17DD, BioManguinhos) nos participantes incluídos na Etapa 2;
- · Avaliar o perfil das cØlulas centrais da imunidade inata e adaptativa (incluindo cØlulas B), bem como possíveis biomarcadores, relacionados à imunogenicidade da vacina contra a Febre Amarela após dose de reforço da vacina contra Febre Amarela (17DD, BioManguinhos) nos participantes incluídos na Etapa 2;
- · Avaliar o desenvolvimento de memória imunológica inata e seu impacto na produçªo de anticorpos neutralizantes contra a Febre Amarela após dose de reforço da vacina contra Febre Amarela (17DD, BioManguinhos) nos participantes incluídos na Etapa 2.

## Avaliaçªo dos Riscos e Benefícios:

Riscos:

- (1) eventos adversos conhecidos de vacina licenciada e disponível nas unidades municipais de saœde para uso de rotina, e (2) hematoma e equimose resultantes da venopunçªo para os exames laboratoriais.

## Benefícios:

O benefício direto da participaçªo serÆ a informaçªo sobre a soropositividade que nªo Ø verificada na rotina.

## ComentÆrios e Consideraçıes sobre a Pesquisa:

Na Carta de Emenda encaminhada ao CEP, a pesquisadora responsÆvel apresenta um SumÆrio das revisıes propostas no protocolo, conforme exposto a seguir:

'Esta emenda tem duas revisıes principais:

- (1) esclarecer que anÆlises de bancada de cØlulas B serªo realizadas no laboratório do Centro de Pesquisa em Vacinas e Preparaçªo para Pandemias, Departamento de Microbiologia, Icahn Escola de Medicina, no Mount Sinai, Nova Iorque, EUA (Center for Vaccine Research and Pandemic

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

Preparedness (C-VARPP), Department of Microbiology, Icahn School of Medicine no Mount Sinai) sob coordenaçªo da Dra. Camila H. Coelho. Para atender a essa modificaçªo, um termo de acordo assinado por mim e pela Dra. Camila H. Coelho estÆ incluindo nessa Carta de Emenda (Anexo 1).

As anÆlises de cØlulas B serªo desenvolvidas no escopo do 'subestudo de avaliaçªo da imunidade celular e de imunoativaçªo' e tambØm na Etapa 2, como parte do componente de 'anÆlises de imunidade inata e adaptativa', conforme detalhamento abaixo.

AnÆlises de cØlulas B no 'subestudo de avaliaçªo da imunidade celular e de imunoativaçªo':

As anÆlises de cØlulas B sªo um refinamento do componente de investigaçıes de imunidade celular e imunoativaçªo jÆ previstos como um subestudo do protocolo no qual 123 participantes foram incluídos no momento de seu ingresso no estudo. Conforme consta no Termo de Consentimento Livre e Esclarecido (versªo 2.0 de 15 de maio de 2017, pÆgina 4), assinado pelos participantes:

'SUBESTUDO DE AVALIA˙ˆO DA IMUNIDADE CELULAR E DE IMUNOATIVA˙ˆO - Alguns participantes do protocolo serªo incluídos em um subestudo de imunidade celular e imunoativaçªo. Este subestudo irÆ nos ajudar a entender se alguns marcadores da imunidade (defesa do corpo) e de inflamaçªo podem estar associados com a resposta à vacina. Este subestudo irÆ incluir tanto participantes infectados pelo HIV quanto participantes nªo infectados pelo HIV.  Para esse subestudo, uma amostra adicional de sangue serÆ coletada (aproximadamente 45ml = 3 colheres de sopa) juntamente com os outros exames previstos pelo protocolo e explicados acima. VocŒ pode escolher participar ou nªo desse subestudo:

Caso eu seja selecionado, desejo participar do subestudo de imunidade celular e imunoativaçªo.

Caso eu seja selecionado, eu nªo desejo participar do subestudo de imunidade celular e imunoativaçªo.'

Para a realizaçªo das anÆlises de cØlulas B, serªo enviadas alíquotas de amostras de PBMC jÆ previstas pelo protocolo para o Mount Sinai - Nova Iorque - EUA. Em sua maioria, essas amostras de PBMC jÆ foram coletadas, processadas e armazenadas; para alguns participantes que ainda nªo realizaram as visitas de Ano 5 do protocolo (que estªo acontecendo atualmente) essas amostras ainda serªo coletadas. É importante ressaltar que nªo serªo necessÆrias coletas adicionais de amostras para a realizaçªo das anÆlises de cØlulas B. Os custos relacionados transporte e anÆlises serªo de responsabilidade do Mount Sinai, e, portanto, nªo haverÆ mudança no orçamento do

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

Continuaçªo do Parecer: 6.158.625

estudo.

Para atender às essas modificaçıes, essa Carta de Emenda contØm uma 'carta aos participantes' que serÆ entregue pessoalmente ou via WhatsApp (para aqueles que assim permitir) para os participantes (n=123) que foram incluídos no 'subestudo de avaliaçªo da imunidade celular e de imunoativaçªo'. Essa carta tem como objetivo comunicar o envio de amostras para o Mount Sinai - Nova Iorque, EUA, explicar que as anÆlises que serªo feitas jÆ estavam contempladas nas investigaçıes do subestudo e detalhar os tipos de cØlulas da imunidade que serªo estudadas (cØlulas B) (Anexo 2).

Essa Carta de Emenda tambØm contØm uma solicitaçªo de dispensa de novo consentimento a ser aplicado a  esses  mesmos  participantes  (n=123)  do  'subestudo  de  avaliaçªo  da  imunidade  celular  e  de imunoativaçªo'. As motivaçıes que justificam esse pedido de dispensa sªo: (i) entendemos que as anÆlises de cØlulas B sªo um refinamento do componente de investigaçıes de imunidade celular e imunoativaçªo jÆ previstos no subestudo, tanto no protocolo quanto no TCLE que foi assinado pelos participantes; (ii) a maior parte dos participantes jÆ tiveram sua visita de Ano 5 realizadas e, de acordo com o cronograma de visitas protocolo só retornarªo para a próxima visita do estudo daqui aproximadamente 5 anos para a visita de Ano 10; (iii) o comparecimento dos participantes ao centro sem a previsªo de uma visita de estudo gera transtornos aos participantes e aumento de custo para o projeto (reembolso financeiro de gastos com transporte) (ver Anexo 3).

## AnÆlises de cØlulas B no escopo da Etapa 2:

As anÆlises de cØlulas B tambØm serªo um refinamento das 'anÆlises de imunidade inata e adaptativa' que estªo previstas no cronograma de visitas da Etapa 2.

A Etapa 2 do estudo Ø constituída pelos participantes do estudo YF-HIV que apresentaram queda dos níveis de anticorpos neutralizantes (&lt; 1:100) durante o seguimento do estudo e que foram convidados para receber uma dose reforço da vacina contra febre amarela e serem acompanhados em visitas de seguimento após a administraçªo da dose de reforço.  Nossa previsªo Ø que cerca de 45-60 participantes (15-20% da populaçªo original do estudo[n=300]) sejam elegíveis para a Etapa 2. No momento, jÆ temos 9 participantes incluídos na Etapa 2.

Importante mencionar que os participantes elegíveis para a etapa 2, elegibilidade essa baseada nos títulos de anticorpos neutralizantes produzidos após a vacinaçªo, podem ou nªo fazerem parte do grupo de participantes incluídos no 'subestudo de avaliaçªo da imunidade celular e de

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

## imunoativaçªo' (n=123).

Para a realizaçªo das anÆlises de cØlulas B, serªo enviadas alíquotas de amostras de PBMC jÆ previstas pelo protocolo (procedimentos da Etapa 2) para o Mount Sinai - Nova Iorque - EUA. Novamente, Ø importante ressaltar que nªo serªo necessÆrias coletas adicionais de amostras para a realizaçªo das anÆlises de cØlulas B.

Para atender à essa modificaçªo, a presente Carta de Emenda contØm uma atualizaçªo do TCLE específico da Etapa 2 que inclui informaçªo sobre o envio de uma alíquota das amostras coletadas para o laboratório do Mount Sinai, Nova Iorque, EUA (Anexo 4).

- (2) modificar o cronograma de visitas da Etapa 2 para incluir uma visita de Ano 1 após a administraçªo da dose de reforço. A adiçªo dessa visita permitirÆ melhor caracterizaçªo da resposta imune e descriçªo da cinØtica  dos  anticorpos  neutralizante  e  dos  demais  componentes  da  resposta  imune,  e  maior comparabilidade com os resultados de resposta imune mensurados após a primeira dose da vacina jÆ que os pontos de coleta serªo semelhantes após a vacinaçªo (Dia 30, Ano 1 e Ano 5).

Para atender à essa modificaçªo, a atualizaçªo do TCLE específico da Etapa 2 mencionada acima (Anexo 4) tambØm incluirÆ informaçªo sobre a realizaçªo da visita da Ano 1.

Vide tópico 'Conclusıes ou PendŒncias e Lista de Inadequaçıes'.

## Consideraçıes sobre os Termos de apresentaçªo obrigatória:

Na Carta de Encaminhamento desta Emenda 5 ao CEP-INI a pesquisadora responsÆvel assim se manifesta:

'Encaminho para apreciaçªo desse ComitŒ de Ética em Pesquisa os seguintes documentos do estudo supracitado:

- - Carta de Emenda n' 5 de 19 de maio de 2023;
- - Protocolo versªo 4.0 de 19 de maio de 2023 (com alteraçıes marcadas, indicando às ediçıes incluídas na Carta de Emenda supracitada);
- - Anexo 1: Termo de acordo entre pesquisador principal do projeto e pesquisador do Centro de Pesquisa em Vacinas e Preparaçªo para Pandemias, Departamento de Microbiologia, Icahn Escola de Medicina, no Mount Sinai / Center for Vaccine Research and Pandemic Preparedness (C-VARPP), Department of Microbiology, Icahn School of Medicine no Mount Sinai;

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

Continuaçªo do Parecer: 6.158.625

- - Anexo 2: Carta aos participantes;
- -  Anexo 3: Pedido de autorizaçªo para dispensa de aplicaçªo de Termo de Consentimento Livre e

## Esclarecido;

- -  Anexo  4:  Termo  de  Consentimento  Livre  e  Esclarecido  referente  à  participaçªo  na  Etapa  3  'Imunogenicidade e segurança da vacina de Febre Amarela em pacientes infectados pelo HIV - ETAPA 2 versªo 4.0 de 19 de maio de 2023 - Carta emenda n'5 de 19 de maio de 2023.'

Vide tópico 'Conclusıes ou PendŒncias e Lista de Inadequaçıes'.

## Recomendaçıes:

Vide tópico 'Conclusıes ou PendŒncias e Lista de Inadequaçıes'.

## Conclusıes ou PendŒncias e Lista de Inadequaçıes:

Sobre o envio de amostras para Mount Sinai - Nova Iorque, EUA:

No TCLE versªo 2.0 de 15 de maio de 2017 - citado na Carta e aprovado por este CEP quando da apreciaçªo da Emenda 1 - consta realmente a opçªo ao participante de participar ou nªo do subestudo de imunidade celular e imunoativaçªo, que contempla a proposta de anÆlises de cØlulas B. No entanto, nªo consta no referido Termo a informaçªo de possível envio de amostras para outra instituiçªo, em especial ao exterior.

Na solicitaçªo de dispensa de TCLE argumenta-se que o 'comparecimento de participantes ao centro sem a previsªo de uma visita de estudo gera transtornos e aumento de custo para o projeto', o que de fato poderia ocorrer, mas nªo justifica o desconhecimento dos participantes sobre o envio de suas amostras biológicas ao exterior.

PEND˚NCIA: Incluir, nesta Emenda 5, o TCLE a ser submetido aos participantes do subestudo de avaliaçªo da imunidade celular e de imunoativaçªo, conforme o Termo que serÆ apresentado aos participantes da Etapa 2 do estudo.

Consideraçıes Finais a critØrio do CEP:

Este parecer foi elaborado baseado nos documentos abaixo relacionados:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

<!-- image -->

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->

Continuaçªo do Parecer: 6.158.625

| Tipo Documento                                                     | Arquivo                                                          | Postagem            | Autor                             | Situaçªo   |
|--------------------------------------------------------------------|------------------------------------------------------------------|---------------------|-----------------------------------|------------|
| TCLE / Termos de Assentimento / Justificativa de AusŒncia          | Anexo_4_TCLE_etapa2_pFA_versao_4 _0_LIMPO.docx                   | 22/05/2023 17:32:23 | FABIO VINICIUS DOS REIS MARQUES   | Aceito     |
| TCLE / Termos de Assentimento / Justificativa de AusŒncia          | Anexo_4_TCLE_etapa2_pFA_versao_4 _0_rodape_CORRIGIDO.docx        | 22/05/2023 17:31:56 | FABIO VINICIUS DOS REIS MARQUES   | Aceito     |
| Informaçıes BÆsicas do Projeto                                     | PB_INFORMA˙ÕES_B`SICAS_214489 0_E5.pdf                           | 19/05/2023 16:04:04 |                                   | Aceito     |
| Outros                                                             | Carta_Encaminhamento_assinada.pdf                                | 19/05/2023 15:51:49 | Marcella Feitosa da Silva Barboza | Aceito     |
| TCLE / Termos de Assentimento / Justificativa de AusŒncia          | Anexo_3_solicitacao_dispensa_TCLE_a ssinada.pdf                  | 19/05/2023 15:50:49 | Marcella Feitosa da Silva Barboza | Aceito     |
| Declaraçªo de Pesquisadores                                        | Anexo_2_carta_participantes_para_envi o_amostras_assinada.pdf    | 19/05/2023 15:50:43 | Marcella Feitosa da Silva Barboza | Aceito     |
| Outros                                                             | Carta_Encaminhamento.doc                                         | 19/05/2023 15:49:32 | Marcella Feitosa da Silva Barboza | Aceito     |
| Declaraçªo de Pesquisadores                                        | Anexo_2_carta_participantes_para_envi o_amostras.docx            | 19/05/2023 15:49:25 | Marcella Feitosa da Silva Barboza | Aceito     |
| Projeto Detalhado / Brochura Investigador                          | carta_emenda_5_16maio_rev_MF_LC.d ocx                            | 19/05/2023 15:48:53 | Marcella Feitosa da Silva Barboza | Aceito     |
| Declaraçªo de Manuseio Material Biológico / Biorepositório /       | Anexo_1_Acordo_Interinstitucional_assi nado.pdf                  | 19/05/2023 15:48:43 | Marcella Feitosa da Silva Barboza | Aceito     |
| Biobanco TCLE / Termos de Assentimento / Justificativa de AusŒncia | Anexo_4_TCLE_etapa2_pFA_versao_4 _0.docx                         | 19/05/2023 15:48:29 | Marcella Feitosa da Silva Barboza | Aceito     |
| TCLE / Termos de Assentimento / Justificativa de AusŒncia          | Anexo_3_solicitacao_dispensa_TCLE.d ocx                          | 19/05/2023 15:48:19 | Marcella Feitosa da Silva Barboza | Aceito     |
| Projeto Detalhado / Brochura Investigador                          | prVFA_HIV_protocolo_versao_4_0_19m ai23_limpo.docx               | 19/05/2023 15:48:05 | Marcella Feitosa da Silva Barboza | Aceito     |
| Projeto Detalhado / Brochura Investigador                          | prVFA_HIV_protocolo_versao_4_0_19m ai23_alteracoes_marcadas.docx | 19/05/2023 15:47:58 | Marcella Feitosa da Silva Barboza | Aceito     |
| Folha de Rosto                                                     | Folha_de_rosto_assinada.pdf                                      | 17/04/2017 11:06:17 | Marcella Feitosa da Silva Barboza | Aceito     |

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

Continuaçªo do Parecer: 6.158.625

Situaçªo do Parecer:

Pendente

Necessita Apreciaçªo da CONEP:

Nªo

RIO DE JANEIRO, 03 de Julho de 2023

Maria InŒs Fernandes Pimentel (Coordenador(a)) Assinado por:

21.040-900

(21)3865-9585

E-mail:

cep@ini.fiocruz.br

Endereço:

Bairro:

CEP:

Telefone:

Avenida Brasil 4365, sala 102 do andar tØrreo do Pavilhªo JosØ Rodrigues da Silva

Manguinhos

UF: RJ

Município:

RIO DE JANEIRO

## INSTITUTO NACIONAL DE INFECTOLOGIA EVANDRO CHAGAS - INI / FIOCRUZ

<!-- image -->